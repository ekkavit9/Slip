
import os
from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import JSONResponse
from google.oauth2 import service_account
from googleapiclient.discovery import build
from google.cloud import vision
from dotenv import load_dotenv
import io
from PIL import Image
import base64
import datetime

load_dotenv()
app = FastAPI()

SHEET_ID = os.getenv("SHEET_ID")
SHEET_NAME_NEW = os.getenv("SHEET_NAME_NEW")
SHEET_NAME_OLD = os.getenv("SHEET_NAME_OLD")

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
creds = service_account.Credentials.from_service_account_file(
    "credentials.json", scopes=SCOPES)
service = build("sheets", "v4", credentials=creds)
sheet = service.spreadsheets()

@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    try:
        content = await file.read()
        image = vision.Image(content=content)
        client = vision.ImageAnnotatorClient()
        response = client.text_detection(image=image)
        texts = response.text_annotations

        if not texts:
            return JSONResponse(content={"error": "No text detected"}, status_code=400)

        full_text = texts[0].description

        name, amount = "", ""
        for line in full_text.split("\n"):
            if "นาย" in line or "นาง" in line or "น.ส." in line:
                name = line.strip()
            if "฿" in line or line.replace(",", "").replace(".", "").isdigit():
                amount = line.strip().replace("฿", "").replace(",", "")

        today = datetime.datetime.now().strftime("%Y-%m-%d")
        new_row = [today, name, amount, "รอตรวจสอบ"]
        sheet.values().append(
            spreadsheetId=SHEET_ID,
            range=f"{SHEET_NAME_NEW}!A:D",
            valueInputOption="RAW",
            body={"values": [new_row]}
        ).execute()

        # ตรวจสอบจากชีตเก่า
        result = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range=f"{SHEET_NAME_OLD}!A:Z"
        ).execute()
        rows = result.get("values", [])

        status = "ยังไม่โอน"
        for row in rows:
            if name in row[0]:
                expected_amount = row[-1].replace(",", "").strip()
                if expected_amount == amount:
                    status = "ตรง"
                else:
                    status = "ยอดไม่ตรง"
                break

        # ดึงจำนวนแถวเพื่อคำนวณแถวล่าสุด
        sheet_data = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range=f"{SHEET_NAME_NEW}!A:A"
        ).execute()
        current_rows = len(sheet_data.get("values", []))
        update_range = f"{SHEET_NAME_NEW}!D{current_rows}"

        # อัปเดตสถานะ
        sheet.values().update(
            spreadsheetId=SHEET_ID,
            range=update_range,
            valueInputOption="RAW",
            body={"values": [[status]]}
        ).execute()

        return {"status": "success", "name": name, "amount": amount, "ตรวจสอบแล้ว": status}

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)
